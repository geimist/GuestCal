GuestCal 2: Bitte lesen

GuestCal ist ein webbasierter Belegungskalender, der sich insbesondere für Websites von Ferienwohnungen eignet.

Bitte lesen Sie die sorgfältig die nachfolgenden Anmerkungen und lesen Sie zur Installation die Datei INSTALL.de.txt. Aktuelle Informationen finden Sie unter http://www.guestcal.de/


### Kontaktinformationen ###

GuestCal wird herausgegeben von dotplex e.K., Laubacher Str. 5, 14197 Berlin, Deutschland. Supportanfragen werden nur für lizenzierte Anwender über info@dotplex.de beantwortet.


### Zugriffskontrolle für den Admin-Bereich ###

GuestCal verfügt in dieser Version noch über keine Benutzerverwaltung. Sie sind selbst dafür verantwortlich, den Admin-Bereich entsprechend abzusichern.
Wenn Sie GuestCal auf einem Apache-Server installieren, geht das am einfachsten über eine .htaccess-Datei. Es genügt, das Verzeichnis "admin/" mit einem Paßwort zu schützen. Eine Anleitung dazu finden Sie z.B. unter:
http://de.selfhtml.org/servercgi/server/htaccess.htm#verzeichnisschutz
In den meisten Fällen bietet auch Ihr Webhosting-Provider eine einfache Möglichkeit, bestimmte Verzeichnisse zu schützen.


### Mehrsprachigkeit ###

GuestCal 2.0 ist mehrsprachig. Vorinstalliert sind die Sprachen Deutsch und Englisch. Wenn Sie weitere Sprachen installieren möchten, gehen Sie wiefolgt vor:

1. Kopieren Sie eine der bestehenden Sprachdateien im Verzeichnis "lang/" in eine neue Datei, z.B. "xyz.inc.php". Der Teil "xyz" darf höchstens 3 Zeichen lang sein.

2. Fügen Sie eine weitere Zeile in die Datenbanktabelle "languages" ein:
	- "id" wird automatisch gesetzt.
	- "name" ist der Name der Sprache.
	- "abbr" muß der erste Teil des Dateinamens sein, in o.g. Bsp. "xyz".
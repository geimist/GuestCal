GuestCal 2: Read me

GuestCal is a web-based occupation calendar, especially developed for websites of holiday apartments.

Please read carefully the following notices and read for installation instructions the file INSTALL.txt. You can find up to date informations at http://www.guestcal.com/


### Contact information ###

GuestCal is published by dotplex e.K., Laubacher Str. 5, 14197 Berlin, Germany. Support questions will only be answered for licensed users at info@dotplex.de.


### Access control for administration panel ###

GuestCal doesn't have any access control in this version. You're responsible to secure the administration panel as appropriate.
If you install GuestCal on an Apache-server, that is best to do with a .htaccess-file. It meets requirements to secure the directory "admin/" with password. You can find a tutorial at:
http://httpd.apache.org/docs/2.2/howto/auth.html
In most cases your webhosting provider also offers a simple interface to secure certain directories.


### Mehrsprachigkeit ###

GuestCal 2.0 is multilingual. German and English are preinstalled. If you like to install new languages, follow these steps:

1. Copy one of the existing language files in directory "lang/" into a new file, e.g. "xyz.inc.php". The part "xyz" is limited to 3 chars.

2. Add a new row into the database table "languages":
	- "id" will be automatically set.
	- "name" is the name of the language.
	- "abbr" is the first part of the language file, e.g. "xyz".